package org.example;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.OptionalDouble;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

class StatisticsUtilsTest {

    @Test
    void calculateAverage_normalCase() {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
        OptionalDouble average = StatisticsUtils.calculateAverage(numbers);
        assertTrue(average.isPresent());
        assertEquals(3.0, average.getAsDouble(), 0.001);
    }

    @Test
    void calculateAverage_emptyList() {
        List<Integer> numbers = Collections.emptyList();
        OptionalDouble average = StatisticsUtils.calculateAverage(numbers);
        assertFalse(average.isPresent());
    }

    @Test
    void calculateAverage_nullList() {
        OptionalDouble average = StatisticsUtils.calculateAverage(null);
        assertFalse(average.isPresent());
    }

    @ParameterizedTest
    @MethodSource("averageTestCases")
    void calculateAverage_parameterized(List<Integer> numbers, double expectedAverage) {
        OptionalDouble average = StatisticsUtils.calculateAverage(numbers);
        if (numbers == null || numbers.isEmpty()) {
            assertFalse(average.isPresent());
        } else {
            assertTrue(average.isPresent());
            assertEquals(expectedAverage, average.getAsDouble(), 0.001);
        }
    }

    private static Stream<Arguments> averageTestCases() {
        return Stream.of(
                Arguments.of(Arrays.asList(1, 2, 3, 4, 5), 3.0),
                Arguments.of(Arrays.asList(10, 20, 30), 20.0),
                Arguments.of(Arrays.asList(7), 7.0),
                Arguments.of(Collections.emptyList(), 0.0), // Expected to be empty, but for parameterized test, we provide a dummy value
                Arguments.of(null, 0.0) // Expected to be empty
        );
    }

    @Test
    void calculateMedian_oddNumberOfElements() {
        List<Integer> numbers = Arrays.asList(1, 3, 2, 5, 4);
        OptionalDouble median = StatisticsUtils.calculateMedian(numbers);
        assertTrue(median.isPresent());
        assertEquals(3.0, median.getAsDouble(), 0.001);
    }

    @Test
    void calculateMedian_evenNumberOfElements() {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4);
        OptionalDouble median = StatisticsUtils.calculateMedian(numbers);
        assertTrue(median.isPresent());
        assertEquals(2.5, median.getAsDouble(), 0.001);
    }

    @Test
    void calculateMedian_emptyList() {
        List<Integer> numbers = Collections.emptyList();
        OptionalDouble median = StatisticsUtils.calculateMedian(numbers);
        assertFalse(median.isPresent());
    }

    @Test
    void calculateMedian_nullList() {
        OptionalDouble median = StatisticsUtils.calculateMedian(null);
        assertFalse(median.isPresent());
    }

    @ParameterizedTest
    @MethodSource("medianTestCases")
    void calculateMedian_parameterized(List<Integer> numbers, double expectedMedian) {
        OptionalDouble median = StatisticsUtils.calculateMedian(numbers);
        if (numbers == null || numbers.isEmpty()) {
            assertFalse(median.isPresent());
        } else {
            assertTrue(median.isPresent());
            assertEquals(expectedMedian, median.getAsDouble(), 0.001);
        }
    }

    private static Stream<Arguments> medianTestCases() {
        return Stream.of(
                Arguments.of(Arrays.asList(1, 2, 3, 4, 5), 3.0),
                Arguments.of(Arrays.asList(10, 20, 30, 40), 25.0),
                Arguments.of(Arrays.asList(7), 7.0),
                Arguments.of(Collections.emptyList(), 0.0),
                Arguments.of(null, 0.0)
        );
    }

    @Test
    void calculateSum_normalCase() {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
        OptionalDouble sum = StatisticsUtils.calculateSum(numbers);
        assertTrue(sum.isPresent());
        assertEquals(15.0, sum.getAsDouble(), 0.001);
    }

    @Test
    void calculateSum_emptyList() {
        List<Integer> numbers = Collections.emptyList();
        OptionalDouble sum = StatisticsUtils.calculateSum(numbers);
        assertFalse(sum.isPresent());
    }

    @Test
    void calculateSum_nullList() {
        OptionalDouble sum = StatisticsUtils.calculateSum(null);
        assertFalse(sum.isPresent());
    }

    @ParameterizedTest
    @MethodSource("sumTestCases")
    void calculateSum_parameterized(List<Integer> numbers, double expectedSum) {
        OptionalDouble sum = StatisticsUtils.calculateSum(numbers);
        if (numbers == null || numbers.isEmpty()) {
            assertFalse(sum.isPresent());
        } else {
            assertTrue(sum.isPresent());
            assertEquals(expectedSum, sum.getAsDouble(), 0.001);
        }
    }

    private static Stream<Arguments> sumTestCases() {
        return Stream.of(
                Arguments.of(Arrays.asList(1, 2, 3, 4, 5), 15.0),
                Arguments.of(Arrays.asList(10, 20, 30), 60.0),
                Arguments.of(Arrays.asList(7), 7.0),
                Arguments.of(Collections.emptyList(), 0.0),
                Arguments.of(null, 0.0)
        );
    }
}
