package org.example;

import java.util.List;
import java.util.OptionalDouble;

public class StatisticsUtils {

    public static OptionalDouble calculateAverage(List<Integer> numbers) {
        if (numbers == null || numbers.isEmpty()) {
            return OptionalDouble.empty();
        }
        return numbers.stream().mapToDouble(Integer::doubleValue).average();
    }

    public static OptionalDouble calculateMedian(List<Integer> numbers) {
        if (numbers == null || numbers.isEmpty()) {
            return OptionalDouble.empty();
        }
        List<Integer> sortedNumbers = numbers.stream().sorted().toList();
        int middle = sortedNumbers.size() / 2;
        if (sortedNumbers.size() % 2 == 1) {
            return OptionalDouble.of(sortedNumbers.get(middle));
        } else {
            return OptionalDouble.of((sortedNumbers.get(middle - 1) + sortedNumbers.get(middle)) / 2.0);
        }
    }

    public static OptionalDouble calculateSum(List<Integer> numbers) {
        if (numbers == null || numbers.isEmpty()) {
            return OptionalDouble.empty();
        }
        return OptionalDouble.of(numbers.stream().mapToDouble(Integer::doubleValue).sum());
    }
}
